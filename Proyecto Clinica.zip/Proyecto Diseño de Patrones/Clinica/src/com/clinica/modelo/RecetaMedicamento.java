package com.clinica.modelo;

public class RecetaMedicamento {

    private int idReceta;
    private int idConsulta;
    private int idMedicina;
    private String dosis;
    private int cantidadPrescrita;

    private String nombreMedicina;

    public RecetaMedicamento() {
    }

    public int getIdReceta() {
        return idReceta;
    }

    public void setIdReceta(int idReceta) {
        this.idReceta = idReceta;
    }

    public int getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public int getIdMedicina() {
        return idMedicina;
    }

    public void setIdMedicina(int idMedicina) {
        this.idMedicina = idMedicina;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public int getCantidadPrescrita() {
        return cantidadPrescrita;
    }

    public void setCantidadPrescrita(int cantidadPrescrita) {
        this.cantidadPrescrita = cantidadPrescrita;
    }

    public String getNombreMedicina() {
        return nombreMedicina;
    }

    public void setNombreMedicina(String nombreMedicina) {
        this.nombreMedicina = nombreMedicina;
    }
}