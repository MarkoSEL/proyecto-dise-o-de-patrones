package com.clinica.modelo;

public class ReporteItem {

    private String agrupador;
    private int numeroConsultas;
    private double ingresoConsultas;
    private int numeroVentasMedicina;
    private double ingresoMedicinas;
    private double costoMedicinas;

    public ReporteItem() {
    }

    public String getAgrupador() {
        return agrupador;
    }

    public void setAgrupador(String agrupador) {
        this.agrupador = agrupador;
    }

    public int getNumeroConsultas() {
        return numeroConsultas;
    }

    public void setNumeroConsultas(int numeroConsultas) {
        this.numeroConsultas = numeroConsultas;
    }

    public double getIngresoConsultas() {
        return ingresoConsultas;
    }

    public void setIngresoConsultas(double ingresoConsultas) {
        this.ingresoConsultas = ingresoConsultas;
    }

    public int getNumeroVentasMedicina() {
        return numeroVentasMedicina;
    }

    public void setNumeroVentasMedicina(int numeroVentasMedicina) {
        this.numeroVentasMedicina = numeroVentasMedicina;
    }

    public double getIngresoMedicinas() {
        return ingresoMedicinas;
    }

    public void setIngresoMedicinas(double ingresoMedicinas) {
        this.ingresoMedicinas = ingresoMedicinas;
    }

    public double getCostoMedicinas() {
        return costoMedicinas;
    }

    public void setCostoMedicinas(double costoMedicinas) {
        this.costoMedicinas = costoMedicinas;
    }
    
    // --- Métodos Calculados ---
    
    public double getGananciaMedicinas() {
        return this.ingresoMedicinas - this.costoMedicinas;
    }
    
    public double getGananciaTotal() {
        return this.ingresoConsultas + getGananciaMedicinas();
    }
}