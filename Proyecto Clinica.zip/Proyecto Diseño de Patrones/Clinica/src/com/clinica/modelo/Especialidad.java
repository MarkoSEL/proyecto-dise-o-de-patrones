package com.clinica.modelo;

public class Especialidad {

    private int idEspecialidad;
    private String nombre;
    private double precioConsulta;

    public Especialidad() {
    }

    public Especialidad(int idEspecialidad, String nombre, double precioConsulta) {
        this.idEspecialidad = idEspecialidad;
        this.nombre = nombre;
        this.precioConsulta = precioConsulta;
    }

    public int getIdEspecialidad() {
        return idEspecialidad;
    }

    public void setIdEspecialidad(int idEspecialidad) {
        this.idEspecialidad = idEspecialidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecioConsulta() {
        return precioConsulta;
    }

    public void setPrecioConsulta(double precioConsulta) {
        this.precioConsulta = precioConsulta;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
