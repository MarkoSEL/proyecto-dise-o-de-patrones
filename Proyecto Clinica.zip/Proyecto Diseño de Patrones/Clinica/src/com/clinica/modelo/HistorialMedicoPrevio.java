package com.clinica.modelo;

public class HistorialMedicoPrevio {

    private int idHistorial;
    private int idPaciente;
    private String malestarMotivo;
    private Integer id_especialidad;
    private boolean atendioClinica;
    private String medicoExterno;
    private String fechaAtencion;
    private boolean noRecuerdaFecha;
    private String diagnostico;
    private String medicamentosRecordados;

    public HistorialMedicoPrevio(String malestarMotivo, Integer id_especialidad, boolean atendioClinica, String medicoExterno, String fechaAtencion, boolean noRecuerdaFecha, String diagnostico, String medicamentosRecordados) {
        this.malestarMotivo = malestarMotivo;
        this.id_especialidad = id_especialidad;
        this.atendioClinica = atendioClinica;
        this.medicoExterno = medicoExterno;
        this.fechaAtencion = fechaAtencion;
        this.noRecuerdaFecha = noRecuerdaFecha;
        this.diagnostico = diagnostico;
        this.medicamentosRecordados = medicamentosRecordados;
    }

    public HistorialMedicoPrevio() {}

    public int getIdHistorial() {
        return idHistorial;
    }

    public void setIdHistorial(int idHistorial) {
        this.idHistorial = idHistorial;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getMalestarMotivo() {
        return malestarMotivo;
    }

    public void setMalestarMotivo(String malestarMotivo) {
        this.malestarMotivo = malestarMotivo;
    }

    public Integer getId_especialidad() {
        return id_especialidad;
    }

    public void setId_especialidad(Integer id_especialidad) {
        this.id_especialidad = id_especialidad;
    }

    public boolean isAtendioClinica() {
        return atendioClinica;
    }

    public void setAtendioClinica(boolean atendioClinica) {
        this.atendioClinica = atendioClinica;
    }

    public String getMedicoExterno() {
        return medicoExterno;
    }

    public void setMedicoExterno(String medicoExterno) {
        this.medicoExterno = medicoExterno;
    }

    public String getFechaAtencion() {
        return fechaAtencion;
    }

    public void setFechaAtencion(String fechaAtencion) {
        this.fechaAtencion = fechaAtencion;
    }

    public boolean isNoRecuerdaFecha() {
        return noRecuerdaFecha;
    }

    public void setNoRecuerdaFecha(boolean noRecuerdaFecha) {
        this.noRecuerdaFecha = noRecuerdaFecha;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getMedicamentosRecordados() {
        return medicamentosRecordados;
    }

    public void setMedicamentosRecordados(String medicamentosRecordados) {
        this.medicamentosRecordados = medicamentosRecordados;
    }
}