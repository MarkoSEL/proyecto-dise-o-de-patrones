package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.HistorialMedicoPrevio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class HistorialMedicoPrevioDAO {

    private final Connection cnn;

    public HistorialMedicoPrevioDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }

    public boolean registrarHistorial(HistorialMedicoPrevio historial, int idPaciente) {
        String sql = "INSERT INTO Historial_Medico_Previo (id_paciente, malestar_motivo, id_especialidad, " +
                     "atendio_clinica, medico_externo, fecha_atencion, no_recuerda_fecha, " +
                     "diagnostico, medicamentos_recordados) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idPaciente);
            ps.setString(2, historial.getMalestarMotivo());
            
            if (historial.getId_especialidad() != null) {
                ps.setInt(3, historial.getId_especialidad());
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            
            ps.setBoolean(4, historial.isAtendioClinica());
            ps.setString(5, historial.getMedicoExterno());
            ps.setString(6, historial.getFechaAtencion());
            ps.setBoolean(7, historial.isNoRecuerdaFecha());
            ps.setString(8, historial.getDiagnostico());
            ps.setString(9, historial.getMedicamentosRecordados());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar historial previo: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al registrar historial previo: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}