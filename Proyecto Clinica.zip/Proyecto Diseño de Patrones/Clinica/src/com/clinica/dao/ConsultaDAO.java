package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Consulta;
import com.clinica.modelo.RecetaMedicamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.swing.JOptionPane;

public class ConsultaDAO {

    private final Connection cnn;

    public ConsultaDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }

    public boolean guardarConsultaCompleta(Consulta consulta, List<RecetaMedicamento> receta) {
        PreparedStatement psConsulta = null;
        PreparedStatement psReceta = null;
        ResultSet rsConsulta = null;

        String sqlConsulta = "INSERT INTO Consultas (id_cita, diagnostico) VALUES (?, ?)";
        String sqlReceta = "INSERT INTO Receta_Medicamentos (id_consulta, id_medicina, dosis, cantidad_prescrita) " +
                           "VALUES (?, ?, ?, ?)";

        try {
            // 1. Iniciar Transacción
            cnn.setAutoCommit(false);

            // 2. Insertar Consulta
            psConsulta = cnn.prepareStatement(sqlConsulta, Statement.RETURN_GENERATED_KEYS);
            psConsulta.setInt(1, consulta.getIdCita());
            psConsulta.setString(2, consulta.getDiagnostico());
            psConsulta.executeUpdate();

            // 3. Obtener el ID de la Consulta creada
            rsConsulta = psConsulta.getGeneratedKeys();
            if (!rsConsulta.next()) {
                throw new SQLException("Falló al crear la consulta, no se obtuvo ID.");
            }
            int idConsultaNueva = rsConsulta.getInt(1);

            // 4. Insertar Receta
            psReceta = cnn.prepareStatement(sqlReceta);
            for (RecetaMedicamento item : receta) {
                psReceta.setInt(1, idConsultaNueva);
                psReceta.setInt(2, item.getIdMedicina());
                psReceta.setString(3, item.getDosis());
                psReceta.setInt(4, item.getCantidadPrescrita());
                psReceta.addBatch();
            }
            psReceta.executeBatch();

            // 5. Confirmar Transacción
            cnn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Error en la transacción de consulta: " + e.getMessage());
            try {
                if (cnn != null) {
                    cnn.rollback();
                    JOptionPane.showMessageDialog(null, "Error al guardar consulta: " + e.getMessage(), "Error de Transacción", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException se) {
                System.err.println("Error en el rollback: " + se.getMessage());
            }
            return false;
        } finally {
            // 6. Cerrar todo y restaurar AutoCommit
            try {
                if (rsConsulta != null) rsConsulta.close();
                if (psConsulta != null) psConsulta.close();
                if (psReceta != null) psReceta.close();
                if (cnn != null) {
                    cnn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    // (Faltarían métodos para listar/modificar consultas y recetas, 
    // los añadiremos si son necesarios para el MODIFICAR de la consulta)
}