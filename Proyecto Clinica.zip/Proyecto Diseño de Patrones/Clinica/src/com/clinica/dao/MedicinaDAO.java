package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Medicina;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MedicinaDAO {

    private final Connection cnn;

    public MedicinaDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }
    
    public List<Medicina> listarMedicinas(String filtroNombre) {
        List<Medicina> medicinas = new ArrayList<>();
        String sql = "SELECT * FROM Medicinas WHERE nombre LIKE ? ORDER BY nombre ASC";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, "%" + filtroNombre + "%");
            rs = ps.executeQuery();

            while (rs.next()) {
                medicinas.add(new Medicina(
                    rs.getInt("id_medicina"),
                    rs.getString("nombre"),
                    rs.getInt("cantidad_stock"),
                    rs.getDouble("costo_unitario"),
                    rs.getDouble("precio_venta_unitario")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar medicinas: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar medicinas: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return medicinas;
    }
    
    public boolean registrarMedicina(Medicina medicina) {
        String sql = "INSERT INTO Medicinas (nombre, cantidad_stock, costo_unitario, precio_venta_unitario) " +
                     "VALUES (?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, medicina.getNombre());
            ps.setInt(2, medicina.getCantidadStock());
            ps.setDouble(3, medicina.getCostoUnitario());
            ps.setDouble(4, medicina.getPrecioVentaUnitario());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar medicina: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El nombre de la medicina ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar medicina: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public boolean modificarMedicina(Medicina medicina) {
        String sql = "UPDATE Medicinas SET nombre = ?, cantidad_stock = ?, costo_unitario = ?, precio_venta_unitario = ? " +
                     "WHERE id_medicina = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, medicina.getNombre());
            ps.setInt(2, medicina.getCantidadStock());
            ps.setDouble(3, medicina.getCostoUnitario());
            ps.setDouble(4, medicina.getPrecioVentaUnitario());
            ps.setInt(5, medicina.getIdMedicina());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al modificar medicina: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El nombre de la medicina ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar medicina: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public boolean eliminarMedicina(int idMedicina) {
        String sql = "DELETE FROM Medicinas WHERE id_medicina = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idMedicina);
            
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
             if (e.getErrorCode() == 1451) {
                 JOptionPane.showMessageDialog(null, "Error: No se puede eliminar la medicina, está referenciada en una receta o factura.", "Error de Borrado", JOptionPane.ERROR_MESSAGE);
             } else {
                System.err.println("Error al eliminar medicina: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al eliminar medicina: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
             }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}