package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PacienteDAO {
    
    private final Connection cnn;

    public PacienteDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }

    public Paciente registrarPaciente(Paciente paciente) {
        String sql = "INSERT INTO Pacientes (dni, nombres, apellidos, fecha_nacimiento, genero, " +
                     "ocupacion, direccion, telefono, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, paciente.getDni());
            ps.setString(2, paciente.getNombres());
            ps.setString(3, paciente.getApellidos());
            ps.setObject(4, paciente.getFechaNacimiento());
            ps.setString(5, paciente.getGenero());
            ps.setString(6, paciente.getOcupacion());
            ps.setString(7, paciente.getDireccion());
            ps.setString(8, paciente.getTelefono());
            ps.setString(9, paciente.getEmail());

            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    paciente.setIdPaciente(rs.getInt(1));
                    return paciente;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al registrar paciente: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El DNI ingresado ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar paciente: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return null;
    }

    public Paciente buscarPacientePorDNI(String dni) {
        String sql = "SELECT * FROM Pacientes WHERE dni = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, dni);
            rs = ps.executeQuery();

            if (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setIdPaciente(rs.getInt("id_paciente"));
                paciente.setDni(rs.getString("dni"));
                paciente.setNombres(rs.getString("nombres"));
                paciente.setApellidos(rs.getString("apellidos"));
                paciente.setFechaNacimiento(rs.getObject("fecha_nacimiento", LocalDate.class));
                paciente.setGenero(rs.getString("genero"));
                paciente.setOcupacion(rs.getString("ocupacion"));
                paciente.setDireccion(rs.getString("direccion"));
                paciente.setTelefono(rs.getString("telefono"));
                paciente.setEmail(rs.getString("email"));
                return paciente;
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar paciente: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al buscar paciente: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return null;
    }
    
    public List<Paciente> listarPacientes(String filtro) {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT * FROM Pacientes WHERE dni LIKE ? OR nombres LIKE ? OR apellidos LIKE ?";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            String filtroLike = "%" + filtro + "%";
            ps.setString(1, filtroLike);
            ps.setString(2, filtroLike);
            ps.setString(3, filtroLike);
            rs = ps.executeQuery();

            while (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setIdPaciente(rs.getInt("id_paciente"));
                paciente.setDni(rs.getString("dni"));
                paciente.setNombres(rs.getString("nombres"));
                paciente.setApellidos(rs.getString("apellidos"));
                paciente.setFechaNacimiento(rs.getObject("fecha_nacimiento", LocalDate.class));
                paciente.setGenero(rs.getString("genero"));
                paciente.setOcupacion(rs.getString("ocupacion"));
                paciente.setDireccion(rs.getString("direccion"));
                paciente.setTelefono(rs.getString("telefono"));
                paciente.setEmail(rs.getString("email"));
                pacientes.add(paciente);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar pacientes: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar pacientes: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return pacientes;
    }

    public boolean modificarPaciente(Paciente paciente) {
        String sql = "UPDATE Pacientes SET dni = ?, nombres = ?, apellidos = ?, fecha_nacimiento = ?, " +
                     "genero = ?, ocupacion = ?, direccion = ?, telefono = ?, email = ? " +
                     "WHERE id_paciente = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, paciente.getDni());
            ps.setString(2, paciente.getNombres());
            ps.setString(3, paciente.getApellidos());
            ps.setObject(4, paciente.getFechaNacimiento());
            ps.setString(5, paciente.getGenero());
            ps.setString(6, paciente.getOcupacion());
            ps.setString(7, paciente.getDireccion());
            ps.setString(8, paciente.getTelefono());
            ps.setString(9, paciente.getEmail());
            ps.setInt(10, paciente.getIdPaciente());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al modificar paciente: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El DNI ingresado ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar paciente: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}
