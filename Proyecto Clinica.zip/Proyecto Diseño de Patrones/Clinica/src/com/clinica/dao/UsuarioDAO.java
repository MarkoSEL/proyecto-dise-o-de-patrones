package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UsuarioDAO {

    private final Connection cnn;

    public UsuarioDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }

    public Usuario validarUsuario(String usuario, String contraseñaPlana) {
        String sql = "SELECT * FROM Usuarios WHERE usuario = ? AND contraseña = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contraseñaPlana);
            rs = ps.executeQuery();

            if (rs.next()) {
                return new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombres"),
                    rs.getString("apellidos"),
                    rs.getString("dni"),
                    rs.getString("correo"),
                    rs.getString("usuario"),
                    rs.getString("tipo_usuario")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error al validar usuario: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al validar usuario: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return null;
    }

    public boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuarios (nombres, apellidos, dni, correo, usuario, contraseña, tipo_usuario) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, usuario.getNombres());
            ps.setString(2, usuario.getApellidos());
            ps.setString(3, usuario.getDni());
            ps.setString(4, usuario.getCorreo());
            ps.setString(5, usuario.getUsuario());
            ps.setString(6, usuario.getContraseña());
            ps.setString(7, usuario.getTipoUsuario());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El DNI o el nombre de usuario ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar usuario: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }

    public List<Usuario> listarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT id_usuario, nombres, apellidos, dni, correo, usuario, tipo_usuario FROM Usuarios";
        Statement st = null;
        ResultSet rs = null;

        try {
            st = cnn.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                usuarios.add(new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombres"),
                    rs.getString("apellidos"),
                    rs.getString("dni"),
                    rs.getString("correo"),
                    rs.getString("usuario"),
                    rs.getString("tipo_usuario")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar usuarios: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar usuarios: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return usuarios;
    }

    public boolean modificarUsuario(Usuario usuario) {
        StringBuilder sql = new StringBuilder("UPDATE Usuarios SET nombres = ?, apellidos = ?, dni = ?, correo = ?, usuario = ?, tipo_usuario = ?");
        
        boolean cambiarPass = (usuario.getContraseña() != null && !usuario.getContraseña().isEmpty());
        
        if (cambiarPass) {
            sql.append(", contraseña = ?");
        }
        
        sql.append(" WHERE id_usuario = ?");
        
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql.toString());
            ps.setString(1, usuario.getNombres());
            ps.setString(2, usuario.getApellidos());
            ps.setString(3, usuario.getDni());
            ps.setString(4, usuario.getCorreo());
            ps.setString(5, usuario.getUsuario());
            ps.setString(6, usuario.getTipoUsuario());
            
            int paramIndex = 7;
            if (cambiarPass) {
                ps.setString(paramIndex, usuario.getContraseña());
                paramIndex++;
            }
            
            ps.setInt(paramIndex, usuario.getIdUsuario());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al modificar usuario: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El DNI o el nombre de usuario ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar usuario: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }

    public boolean eliminarUsuario(int idUsuario) {
        String sql = "DELETE FROM Usuarios WHERE id_usuario = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
             if (e.getErrorCode() == 1451) {
                 JOptionPane.showMessageDialog(null, "Error: No se puede eliminar al usuario, está referenciado en otra tabla (ej. Médicos).", "Error de Borrado", JOptionPane.ERROR_MESSAGE);
             } else {
                System.err.println("Error al eliminar usuario: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al eliminar usuario: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
             }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}