package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Especialidad;
import com.clinica.modelo.Medico;
import com.clinica.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MedicoDAO {

    private final Connection cnn;

    public MedicoDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }
    
    public List<Medico> listarTodosMedicos() {
        List<Medico> medicos = new ArrayList<>();
        String sql = "SELECT m.id_medico, m.id_usuario, m.codigo_medico, m.celular, " +
                     "u.nombres, u.apellidos, u.dni, u.correo, u.usuario " +
                     "FROM Medicos m " +
                     "JOIN Usuarios u ON m.id_usuario = u.id_usuario " +
                     "WHERE u.tipo_usuario = 'MEDICO'";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Medico medico = new Medico();
                medico.setIdMedico(rs.getInt("id_medico"));
                medico.setIdUsuario(rs.getInt("id_usuario"));
                medico.setCodigoMedico(rs.getString("codigo_medico"));
                medico.setCelular(rs.getString("celular"));
                
                String nombresCompletos = rs.getString("nombres") + " " + rs.getString("apellidos");
                medico.setNombresCompletos(nombresCompletos);
                
                // Cargar también los datos del usuario para el formulario
                medico.setDatosUsuario(
                    rs.getString("nombres"),
                    rs.getString("apellidos"),
                    rs.getString("dni"),
                    rs.getString("correo"),
                    rs.getString("usuario")
                );
                medicos.add(medico);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todos los médicos: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar médicos: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return medicos;
    }
    
    public List<Especialidad> getEspecialidadesPorMedico(int idMedico) {
        List<Especialidad> especialidades = new ArrayList<>();
        String sql = "SELECT e.id_especialidad, e.nombre, e.precio_consulta " +
                     "FROM Especialidades e " +
                     "JOIN Medico_Especialidades me ON e.id_especialidad = me.id_especialidad " +
                     "WHERE me.id_medico = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idMedico);
            rs = ps.executeQuery();

            while (rs.next()) {
                especialidades.add(new Especialidad(
                    rs.getInt("id_especialidad"),
                    rs.getString("nombre"),
                    rs.getDouble("precio_consulta")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener especialidades del médico: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return especialidades;
    }

    public boolean registrarMedicoCompleto(Usuario usuario, Medico medico, List<Especialidad> especialidades) {
        // --- Patrón: Transacción ---
        PreparedStatement psUsuario = null;
        PreparedStatement psMedico = null;
        PreparedStatement psEspecialidad = null;
        ResultSet rsUsuario = null;

        String sqlUsuario = "INSERT INTO Usuarios (nombres, apellidos, dni, correo, usuario, contraseña, tipo_usuario) " +
                            "VALUES (?, ?, ?, ?, ?, ?, 'MEDICO')";
        String sqlMedico = "INSERT INTO Medicos (id_usuario, codigo_medico, celular) VALUES (?, ?, ?)";
        String sqlEspecialidad = "INSERT INTO Medico_Especialidades (id_medico, id_especialidad) VALUES (?, ?)";

        try {
            // 1. Deshabilitar AutoCommit
            cnn.setAutoCommit(false);

            // 2. Insertar Usuario
            psUsuario = cnn.prepareStatement(sqlUsuario, Statement.RETURN_GENERATED_KEYS);
            psUsuario.setString(1, usuario.getNombres());
            psUsuario.setString(2, usuario.getApellidos());
            psUsuario.setString(3, usuario.getDni());
            psUsuario.setString(4, usuario.getCorreo());
            psUsuario.setString(5, usuario.getUsuario());
            psUsuario.setString(6, usuario.getContraseña());
            psUsuario.executeUpdate();

            // 3. Obtener el ID del Usuario creado
            rsUsuario = psUsuario.getGeneratedKeys();
            if (!rsUsuario.next()) {
                throw new SQLException("Falló al crear el usuario, no se obtuvo ID.");
            }
            int idUsuarioNuevo = rsUsuario.getInt(1);

            // 4. Insertar Médico
            psMedico = cnn.prepareStatement(sqlMedico, Statement.RETURN_GENERATED_KEYS);
            psMedico.setInt(1, idUsuarioNuevo);
            psMedico.setString(2, medico.getCodigoMedico());
            psMedico.setString(3, medico.getCelular());
            psMedico.executeUpdate();
            
            // 5. Obtener el ID del Médico creado
            ResultSet rsMedico = psMedico.getGeneratedKeys();
             if (!rsMedico.next()) {
                throw new SQLException("Falló al crear el médico, no se obtuvo ID.");
            }
            int idMedicoNuevo = rsMedico.getInt(1);

            // 6. Insertar Especialidades
            psEspecialidad = cnn.prepareStatement(sqlEspecialidad);
            for (Especialidad esp : especialidades) {
                psEspecialidad.setInt(1, idMedicoNuevo);
                psEspecialidad.setInt(2, esp.getIdEspecialidad());
                psEspecialidad.addBatch();
            }
            psEspecialidad.executeBatch();

            // 7. Si todo fue bien, confirmar (Commit)
            cnn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Error en la transacción de registro de médico: " + e.getMessage());
            try {
                // 8. Si algo falló, deshacer (Rollback)
                if (cnn != null) {
                    cnn.rollback();
                    JOptionPane.showMessageDialog(null, "Error al registrar: " + e.getMessage(), "Error de Transacción", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException se) {
                System.err.println("Error en el rollback: " + se.getMessage());
            }
            return false;
        } finally {
            // 9. Cerrar todo y restaurar AutoCommit
            try {
                if (rsUsuario != null) rsUsuario.close();
                if (psUsuario != null) psUsuario.close();
                if (psMedico != null) psMedico.close();
                if (psEspecialidad != null) psEspecialidad.close();
                if (cnn != null) {
                    cnn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public boolean modificarMedicoCompleto(Usuario usuario, Medico medico, List<Especialidad> nuevasEspecialidades) {
        PreparedStatement psUsuario = null;
        PreparedStatement psMedico = null;
        PreparedStatement psDelEspecialidad = null;
        PreparedStatement psInsEspecialidad = null;

        String sqlUsuario = "UPDATE Usuarios SET nombres = ?, apellidos = ?, dni = ?, correo = ?, usuario = ?";
        if (usuario.getContraseña() != null && !usuario.getContraseña().isEmpty()) {
            sqlUsuario += ", contraseña = ?";
        }
        sqlUsuario += " WHERE id_usuario = ?";
        
        String sqlMedico = "UPDATE Medicos SET codigo_medico = ?, celular = ? WHERE id_medico = ?";
        String sqlDelEspecialidad = "DELETE FROM Medico_Especialidades WHERE id_medico = ?";
        String sqlInsEspecialidad = "INSERT INTO Medico_Especialidades (id_medico, id_especialidad) VALUES (?, ?)";

        try {
            cnn.setAutoCommit(false);

            // 1. Actualizar Usuario
            psUsuario = cnn.prepareStatement(sqlUsuario);
            psUsuario.setString(1, usuario.getNombres());
            psUsuario.setString(2, usuario.getApellidos());
            psUsuario.setString(3, usuario.getDni());
            psUsuario.setString(4, usuario.getCorreo());
            psUsuario.setString(5, usuario.getUsuario());
            int paramIndex = 6;
            if (usuario.getContraseña() != null && !usuario.getContraseña().isEmpty()) {
                psUsuario.setString(paramIndex++, usuario.getContraseña());
            }
            psUsuario.setInt(paramIndex, usuario.getIdUsuario());
            psUsuario.executeUpdate();

            // 2. Actualizar Médico
            psMedico = cnn.prepareStatement(sqlMedico);
            psMedico.setString(1, medico.getCodigoMedico());
            psMedico.setString(2, medico.getCelular());
            psMedico.setInt(3, medico.getIdMedico());
            psMedico.executeUpdate();

            // 3. Borrar Especialidades anteriores
            psDelEspecialidad = cnn.prepareStatement(sqlDelEspecialidad);
            psDelEspecialidad.setInt(1, medico.getIdMedico());
            psDelEspecialidad.executeUpdate();
            
            // 4. Insertar Especialidades nuevas
            psInsEspecialidad = cnn.prepareStatement(sqlInsEspecialidad);
            for (Especialidad esp : nuevasEspecialidades) {
                psInsEspecialidad.setInt(1, medico.getIdMedico());
                psInsEspecialidad.setInt(2, esp.getIdEspecialidad());
                psInsEspecialidad.addBatch();
            }
            psInsEspecialidad.executeBatch();

            cnn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Error en la transacción de modificación de médico: " + e.getMessage());
            try {
                if (cnn != null) {
                    cnn.rollback();
                    JOptionPane.showMessageDialog(null, "Error al modificar: " + e.getMessage(), "Error de Transacción", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException se) {
                System.err.println("Error en el rollback: " + se.getMessage());
            }
            return false;
        } finally {
            try {
                if (psUsuario != null) psUsuario.close();
                if (psMedico != null) psMedico.close();
                if (psDelEspecialidad != null) psDelEspecialidad.close();
                if (psInsEspecialidad != null) psInsEspecialidad.close();
                if (cnn != null) {
                    cnn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }

    public List<Medico> listarMedicosPorEspecialidad(int idEspecialidad) {
        List<Medico> medicos = new ArrayList<>();
        
        String sql = "SELECT m.id_medico, m.id_usuario, m.codigo_medico, m.celular, " +
                     "u.nombres, u.apellidos " +
                     "FROM Medicos m " +
                     "JOIN Usuarios u ON m.id_usuario = u.id_usuario " +
                     "JOIN Medico_Especialidades me ON m.id_medico = me.id_medico " +
                     "WHERE u.tipo_usuario = 'MEDICO' AND me.id_especialidad = ?";
        
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idEspecialidad);
            rs = ps.executeQuery();

            while (rs.next()) {
                Medico medico = new Medico();
                medico.setIdMedico(rs.getInt("id_medico"));
                medico.setIdUsuario(rs.getInt("id_usuario"));
                medico.setCodigoMedico(rs.getString("codigo_medico"));
                medico.setCelular(rs.getString("celular"));
                medico.setNombresCompletos(rs.getString("nombres") + " " + rs.getString("apellidos"));
                medicos.add(medico);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar médicos por especialidad: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar médicos: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return medicos;
    }
}