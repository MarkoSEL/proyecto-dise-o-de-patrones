package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Especialidad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EspecialidadDAO {

    private final Connection cnn;

    public EspecialidadDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }
    
    public List<Especialidad> listarEspecialidades() {
        List<Especialidad> especialidades = new ArrayList<>();
        String sql = "SELECT * FROM Especialidades ORDER BY nombre ASC";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Especialidad esp = new Especialidad(
                    rs.getInt("id_especialidad"),
                    rs.getString("nombre"),
                    rs.getDouble("precio_consulta")
                );
                especialidades.add(esp);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar especialidades: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar especialidades: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return especialidades;
    }
    
    public boolean registrarEspecialidad(Especialidad especialidad) {
        String sql = "INSERT INTO Especialidades (nombre, precio_consulta) VALUES (?, ?)";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, especialidad.getNombre());
            ps.setDouble(2, especialidad.getPrecioConsulta());
            
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar especialidad: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El nombre de la especialidad ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar especialidad: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public boolean modificarEspecialidad(Especialidad especialidad) {
        String sql = "UPDATE Especialidades SET nombre = ?, precio_consulta = ? WHERE id_especialidad = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, especialidad.getNombre());
            ps.setDouble(2, especialidad.getPrecioConsulta());
            ps.setInt(3, especialidad.getIdEspecialidad());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al modificar especialidad: " + e.getMessage());
            if (e.getErrorCode() == 1062) {
                 JOptionPane.showMessageDialog(null, "Error: El nombre de la especialidad ya existe.", "Error Duplicado", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar especialidad: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        } finally {
             try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}