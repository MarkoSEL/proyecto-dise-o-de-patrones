package com.clinica.vistas;

import com.clinica.dao.PacienteDAO;
import com.clinica.modelo.Paciente;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PacientesFrame extends javax.swing.JFrame {

    private final PacienteDAO pacienteDAO;
    private DefaultTableModel pacientesTableModel;
    private DefaultTableModel historialTableModel;
    
    private Paciente pacienteSeleccionado;
    private boolean modoEdicion = false;

    public PacientesFrame() {
        initComponents();
        this.pacienteDAO = new PacienteDAO();
        configurarVentana();
        inicializarTablas();
        cargarPacientes("");
        controlarEdicionCampos(false);
    }
    
    private void configurarVentana() {
        this.setTitle("Consulta de Pacientes");
        this.setLocationRelativeTo(null); 
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    }
    
    private void inicializarTablas() {
        pacientesTableModel = new DefaultTableModel(
            new Object[]{"ID", "DNI", "Nombres", "Apellidos"}, 0) {
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        tblPacientes.setModel(pacientesTableModel);
        
        historialTableModel = new DefaultTableModel(
            new Object[]{"Fecha", "Tipo", "Médico/Especialidad", "Motivo"}, 0) {
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        tblHistorial.setModel(historialTableModel);
    }
    
    private void cargarPacientes(String filtro) {
        pacientesTableModel.setRowCount(0);
        List<Paciente> lista = pacienteDAO.listarPacientes(filtro);
        
        for (Paciente p : lista) {
            pacientesTableModel.addRow(new Object[]{
                p.getIdPaciente(),
                p.getDni(),
                p.getNombres(),
                p.getApellidos()
            });
        }
    }
    
    private void controlarEdicionCampos(boolean habilitar) {
        txtNombres.setEditable(habilitar);
        txtApellidos.setEditable(habilitar);
        jdcFechaNacimiento.setEnabled(habilitar);
        txtGenero.setEditable(habilitar); // Quizás deba ser ComboBox
        txtDireccion.setEditable(habilitar);
        txtTelefono.setEditable(habilitar);
        txtEmail.setEditable(habilitar);
    }
    
    private void limpiarCampos() {
        pacienteSeleccionado = null;
        txtBuscador.setText("");
        
        txtNombres.setText("");
        txtApellidos.setText("");
        jdcFechaNacimiento.setDate(null);
        txtEdad.setText("");
        txtGenero.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        
        historialTableModel.setRowCount(0);
        tblPacientes.clearSelection();
        
        controlarEdicionCampos(false);
        modoEdicion = false;
        btnModificar.setText("MODIFICAR");
    }
    
    private void cargarDatosPaciente() {
        if (pacienteSeleccionado == null) return;
        
        txtNombres.setText(pacienteSeleccionado.getNombres());
        txtApellidos.setText(pacienteSeleccionado.getApellidos());
        
        if (pacienteSeleccionado.getFechaNacimiento() != null) {
            Date fechaNac = Date.from(pacienteSeleccionado.getFechaNacimiento()
                .atStartOfDay(ZoneId.systemDefault()).toInstant());
            jdcFechaNacimiento.setDate(fechaNac);
            txtEdad.setText(pacienteSeleccionado.getEdad() + " años");
        } else {
            jdcFechaNacimiento.setDate(null);
            txtEdad.setText("");
        }
        
        txtGenero.setText(pacienteSeleccionado.getGenero());
        txtDireccion.setText(pacienteSeleccionado.getDireccion());
        txtTelefono.setText(pacienteSeleccionado.getTelefono());
        txtEmail.setText(pacienteSeleccionado.getEmail());
        
        cargarHistorialPaciente();
    }
    
    private void cargarHistorialPaciente() {
        historialTableModel.setRowCount(0);
        if (pacienteSeleccionado == null) return;
        
        int idPaciente = pacienteSeleccionado.getIdPaciente();
        
        // --- LÓGICA PENDIENTE ---
        // Aquí se deben cargar (fusionados por fecha):
        // 1. DAO.listarHistorialPrevio(idPaciente)
        // 2. DAO.listarConsultas(idPaciente)
        
        // Por ahora, simulamos la carga
        // historialTableModel.addRow(new Object[]{"2025-10-10", "Previo", "Dr. Externo", "Dolor de cabeza"});
        // historialTableModel.addRow(new Object[]{"2025-11-15", "Consulta", "Dr. Pérez (Cardiología)", "Chequeo"});
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtBuscador = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPacientes = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtGenero = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jdcFechaNacimiento = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnModificar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHistorial = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Buscar Paciente (DNI, Nombre o Apellido):");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Consulta de Pacientes");

        txtBuscador.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscadorKeyReleased(evt);
            }
        });

        tblPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblPacientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPacientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPacientes);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Nombres:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Apellidos:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Edad:");

        txtEdad.setEditable(false);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Género:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Dirección:");

        txtDireccion.setEditable(false);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Teléfono:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Fecha de nacimiento:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Email:");

        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModificar.setText("MODIFICAR");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Historial Médico del Paciente");

        tblHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblHistorial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHistorialMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblHistorial);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(25, 25, 25)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel4)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtBuscador, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(26, 26, 26)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addGap(18, 18, 18)
                                    .addComponent(jdcFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(34, 34, 34)
                                    .addComponent(jLabel9)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel10)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtEmail))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtDireccion))
                                .addComponent(jScrollPane2)))))
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(124, 124, 124)
                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(194, 194, 194))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5))
                    .addComponent(jdcFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if (pacienteSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un paciente de la lista.", "Selección Requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (modoEdicion) {
            // --- MODO GUARDAR ---
            
            // Recoger datos de los campos y actualizar el objeto
            pacienteSeleccionado.setNombres(txtNombres.getText().trim());
            pacienteSeleccionado.setApellidos(txtApellidos.getText().trim());
            pacienteSeleccionado.setGenero(txtGenero.getText().trim());
            pacienteSeleccionado.setDireccion(txtDireccion.getText().trim());
            pacienteSeleccionado.setTelefono(txtTelefono.getText().trim());
            pacienteSeleccionado.setEmail(txtEmail.getText().trim());
            
            if (jdcFechaNacimiento.getDate() != null) {
                LocalDate fechaNac = jdcFechaNacimiento.getDate().toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
                pacienteSeleccionado.setFechaNacimiento(fechaNac);
            }

            // Llamar al DAO
            if (pacienteDAO.modificarPaciente(pacienteSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Paciente modificado exitosamente.", "Modificación Exitosa", JOptionPane.INFORMATION_MESSAGE);
                
                // Salir del modo edición
                modoEdicion = false;
                controlarEdicionCampos(false);
                btnModificar.setText("MODIFICAR");
                
                // Recargar la lista
                cargarPacientes(txtBuscador.getText().trim());
            }

        } else {
            // --- MODO MODIFICAR ---
            modoEdicion = true;
            btnModificar.setText("GUARDAR CAMBIOS");
            controlarEdicionCampos(true);
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarCampos();
        cargarPacientes("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtBuscadorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscadorKeyReleased
        String filtro = txtBuscador.getText().trim();
        cargarPacientes(filtro);
        limpiarCampos();
    }//GEN-LAST:event_txtBuscadorKeyReleased

    private void tblPacientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPacientesMouseClicked
        int filaSeleccionada = tblPacientes.getSelectedRow();
        if (filaSeleccionada == -1) return;

        // Limpiar estado de edición anterior
        controlarEdicionCampos(false);
        modoEdicion = false;
        btnModificar.setText("MODIFICAR");

        // Obtener ID y buscar el objeto completo
        // (Es mejor buscar el objeto completo para tener todos los datos)
        int idPaciente = (int) pacientesTableModel.getValueAt(filaSeleccionada, 0);
        
        // --- Patrón: Experto en Información (GRASP) ---
        // La clase PacienteDAO es la experta en buscar pacientes.
        // O podríamos buscar en la lista local si la caché es grande.
        // Por simplicidad y consistencia, buscamos en el DAO.
        
        // CORRECCIÓN: Para evitar otra llamada a la BD, es mejor usar
        // el DNI que ya tenemos en la tabla.
        String dni = (String) pacientesTableModel.getValueAt(filaSeleccionada, 1);
        this.pacienteSeleccionado = pacienteDAO.buscarPacientePorDNI(dni);
        
        cargarDatosPaciente();
    }//GEN-LAST:event_tblPacientesMouseClicked

    private void tblHistorialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHistorialMouseClicked
        // Requisito: Abrir detalle al hacer doble clic
        if (evt.getClickCount() == 2) {
            int fila = tblHistorial.getSelectedRow();
            if (fila == -1) return;
            
            // Lógica pendiente
            JOptionPane.showMessageDialog(this, 
                "Función pendiente: Mostrar detalle de la cita/historial.\n" +
                "Esto se implementará con la 'Interfaz CITA'.", 
                "Pendiente", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_tblHistorialMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private com.toedter.calendar.JDateChooser jdcFechaNacimiento;
    private javax.swing.JTable tblHistorial;
    private javax.swing.JTable tblPacientes;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtBuscador;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
